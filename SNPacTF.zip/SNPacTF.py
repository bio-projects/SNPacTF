# Arguments ########################################################################################
import argparse
from webbrowser import get
parser = argparse.ArgumentParser(description="SNPacTF detects the SNPs affecting the binding of transcription factors to the binding regions. Created By Ahmed Karam. Example command: python3 SNPacTF.py --snp_table '/path/to/snp_table.csv' --snp_fasta '/path/to/snp_fasta.fasta' --comparison_table '/path/to/comparison.tsv' --motif_db '/path/to/motif_databases.12.23' --output '/path/to/output/folder' --prefix 'prefix'")
parser.add_argument('--snp_table', help="Input SNP Table (Full Path)")
parser.add_argument('--snp_fasta', help="Input SNP Fasta (Full Path)")
parser.add_argument('--comparison_table', help="Input Comparison Table (Full Path)")
parser.add_argument('--motif_db', help="Input Folder/Directory Name (Full Path)")
parser.add_argument('--output', help="Output Folder/Directory Name (Full Path)")
parser.add_argument('--prefix', help="File Name Prefix")
args = parser.parse_args()
# Input Files ######################################################################################
## Paste Variant Table File Name (With Full Path)
ensemblTable = args.snp_table
## Paste SNP(s) Fasta File Name (With Full Path)
snpFasta = args.snp_fasta
## Paste Tomtom Result File Name(s) (With Full Path) instead of tomtom.tsv
tomtomResult = args.comparison_table
## Paste Motif Database Folder Path Between Parentheses instead of motif_databases.12.23
motifDatabase = r'%s' %(args.motif_db)
# Output Path
outputPath = args.output
# Output File Prefix
outputPrefix = args.prefix
####################################################################################################
from Bio import SeqIO
from Bio import pairwise2
from Bio.pairwise2 import align,  format_alignment
from Bio.Seq import reverse_complement
import os
# Extract Info from Files ##########################################################################
## ensemblTable
with open(ensemblTable, 'r+') as ensTab:
    ensTabRead = ensTab.read()
    ensTabSplit = ensTabRead.splitlines() # مقسوم لاسطر فقط
    del ensTabSplit[0]
#print(ensTabSplit)
ensTabDict = {}
for i in ensTabSplit:
    splitI = i.split(',')
    snpName = splitI[0]
    snpAlleles = splitI[5].split('/')
    transcriptID = splitI[17]
    ensTabDict[snpName] = [snpAlleles, transcriptID, splitI[2], splitI[10]]
    # index 0 = list of snp allele ['C', 'G']
    # index 1 = transcript id
    # index 2 = Location of SNP
    # index 3 = Conseq. Type
#print(ensTabDict) # اسم السنيب والاليلات في هذا القاموس
##################################################
## snpFasta
snpSeqDict = {}
for seq in SeqIO.parse(snpFasta, 'fasta'):
    snpSeqDict[seq.id.split('|')[3]] = [str(seq.seq), int(((len(str(seq.seq))-1)/2))] # معادلة قسمة طول السيكوينس على اثنين
    # index 0 = snp sequence
    # index 1 = snp position for python
    #print(str(seq.seq)[100])
#print(snpSeqDict)
##################################################
## tomtomResult
with open(tomtomResult, 'r+') as tomTab:
    tomTabRead = tomTab.read()
    tomTabSplit = tomTabRead.splitlines() # مقسوم لاسطر فقط
    del tomTabSplit[0]
tomTabDict = {}
motifDbName = ''
for j in filter(None, tomTabSplit):
    if j[0] == '#':
        splitJ = j.split(' ')
        if 'query_motifs' in splitJ:
            if "\\" in motifDatabase:
                motifDbName = '%s\\%s' %(motifDatabase, '\\'.join(j.split(' ')[splitJ.index('query_motifs')+1][3:].split('/')))
            else:
                motifDbName = '%s/%s' %(motifDatabase, j.split(' ')[splitJ.index('query_motifs')+1][3:])
        else:
            pass
    else:
        splitJ = j.split('\t')
        #print(splitJ)
        dbMotifId = splitJ[1]    
        tomTabDict[dbMotifId] = splitJ
        # index 0 = Query_ID
        # index 1 = Target_ID
        # index 2 = Optimal_offset
        # index 3 = p-value
        # index 4 = E-value
        # index 5 = q-value
        # index 6 = Overlap
        # index 7 = Query_consensus
        # index 8 = Target_consensus
        # index 9 = Orientation
#print(tomTabDict) # اسم السنيب والاليلات في هذا القاموس
#print(motifDbName)
####################################################################################################
scriptResult = ["SNP_ID\tSNP_alleles\tSNP_position\tSNP_type\tTranscript_ID\tMotif_ID\tSNP_position_in_the_motif(+Strand|5'->3')\tMotif_orientation(+Normal|-Reverse_complement)\tAccepted_alleles\tUnaccepted_alleles"]
## Pairwise Alignment ##############################################################################
for k in snpSeqDict.keys():
    sequenceOfSnp = snpSeqDict[k][0]
    positionOfSnp = snpSeqDict[k][1]
    
    for indl, l in enumerate(tomTabDict.keys()):
        getBestAlgin = 2
        queryCons = tomTabDict[l][7]
        targetCons = tomTabDict[l][8]
        # محاذاه للحصول على افضل محاذاه ما اذا كانت على الشريط العادي ام الشريط المعكوس المكمل
        firLocalAlign = pairwise2.align.localxs(sequenceOfSnp, queryCons, -10, -0.1)
        revFirLocalAlign = pairwise2.align.localxs(sequenceOfSnp, reverse_complement(queryCons), -10, -0.1)
        alginments = [firLocalAlign[0][2], revFirLocalAlign[0][2]]
        getBestAlgin = alginments.index(max(firLocalAlign[0][2], revFirLocalAlign[0][2]))
        
        if getBestAlgin == 1:
            optAlign = revFirLocalAlign
            # في حالة ما اذا تم عمل المحاذاه للمعكوس المكمل فانه يجب البحث في الموتيف المعكوس المكمل
            # نقوم هنا باستخراج القطع المتحاذاه من خلال المواقع الناتجه من المحاذاه الزوجية والمواقع الوارده في تومتوم
            motifOnSnp = reverse_complement(optAlign[0][0][optAlign[0][3]:optAlign[0][4]])[abs(int(tomTabDict[l][2])):abs(int(tomTabDict[l][2]))+int(tomTabDict[l][6])]
        elif getBestAlgin == 0:
            optAlign = firLocalAlign
            motifOnSnp = optAlign[0][0][optAlign[0][3]:optAlign[0][4]][abs(int(tomTabDict[l][2])):abs(int(tomTabDict[l][2]))+int(tomTabDict[l][6])]
            # optAlign[0][3] + abs(int(tomTabDict[l][2])) : optAlign[0][3] + abs(int(tomTabDict[l][2])) + int(tomTabDict[l][6])
        
        # استبعد الموتيف المُتنبأ به الذي يحتوي على شرطة في منطقة السنيب والذي يعني ان هذا الموتيف لم يتحاذى مع السنيب
        if optAlign[0][1][positionOfSnp] != '-':

            # اذا كانت علامة اندرسكور موجوده في القطعة المتحاذاه المستخرجه فاكمل
            if "_" in motifOnSnp:
                snpOnDbMotifPosition = 0
                
                if tomTabDict[l][9] == '-':
                    snpOnDbMotifPosition = reverse_complement(motifOnSnp).find('_') + 1
                else:
                    snpOnDbMotifPosition = motifOnSnp.find('_') + 1

                # فتح ملف قاعده البيانات المذكور في جدول تومتوم
                with open(motifDbName, 'r+') as motifDB:
                    readMotifDB = motifDB.read()
                    splitMotifDB = readMotifDB.splitlines()
                
                # استخراج السطر الذي يتوافق مع موقع السنيب والذي يحتوي على التكرارات
                for indM, m in enumerate(splitMotifDB):
                    if 'MOTIF %s'%l in m:
                        #print(snpOnDbMotifPosition)
                        #print(m, indM+1+snpOnDbMotifPosition)
                        snpFreq = splitMotifDB[indM+1+snpOnDbMotifPosition][1:].split('  ')
                        # index 0 = A
                        # index 1 = C
                        # index 2 = G
                        # index 3 = T
                        #print(l, snpFreq, )
                        
                        # تحديد الاتجاه
                        strand = ''
                        if getBestAlgin == 1 and tomTabDict[l][9] == '-':
                            strand = '+'
                        elif getBestAlgin == 1 and tomTabDict[l][9] == '+':
                            strand = '-'
                        elif getBestAlgin == 0 and tomTabDict[l][9] == '-':
                            strand = '-'
                        elif getBestAlgin == 0 and tomTabDict[l][9] == '+':
                            strand = '+'

                        # تجميع النيوكليوتيدات من قاعده البيانات حسب التكرار
                        alleleFreq = []
                        for indN, n in enumerate(snpFreq):
                            if float(n) > 0:
                                # يتم ايضا تحديد النيوكليوتيدات بناءا على الستراند بوزيتيف او نيجاتيف اي لابد من تغيير التكرارات لانني اتعامل مع المحاذاه كما هي فمثلا ما هو جي لابد وان يكون سي في حالة المعكوس المكمل
                                if strand == '+':
                                    if indN == 0:
                                        alleleFreq.append('A')
                                    elif indN == 1:
                                        alleleFreq.append('C')
                                    elif indN == 2:
                                        alleleFreq.append('G')
                                    elif indN == 3:
                                        alleleFreq.append('T')
                                else:
                                    if indN == 0:
                                        alleleFreq.append('T')
                                    elif indN == 1:
                                        alleleFreq.append('G')
                                    elif indN == 2:
                                        alleleFreq.append('C')
                                    elif indN == 3:
                                        alleleFreq.append('A')
                        
                        #print(ensTabDict[k][0], alleleFreq)
                        # مقارنة الاليلات المرجعية بالاليلات الوارده في النيوكليوتيدات المُجمعه من قاعده البيانات لمعرفه ما هو المسموح به
                        accebtableSNPs = []
                        unaceptedSNPs = []
                        for o in ensTabDict[k][0]:
                            if o in alleleFreq:
                                accebtableSNPs.append(o)
                            else:
                                unaceptedSNPs.append(o)
                        
                        scriptResult.append('%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s\t%s' %(k, '/'.join(ensTabDict[k][0]), ensTabDict[k][2], ensTabDict[k][3], ensTabDict[k][1], l, snpOnDbMotifPosition, strand, '/'.join(accebtableSNPs), '/'.join(unaceptedSNPs)))
                        
if outputPath:
    os.chdir(outputPath)
    if outputPrefix:
        with open('%s_snpactf_result.tab'%outputPrefix, 'w+') as w:
            w.write('\n'.join(scriptResult))
    else:
        with open('snpactf_result.tab', 'w+') as w:
            w.write('\n'.join(scriptResult))
else:
    if outputPrefix:
        with open('%s_snpactf_result.tab'%outputPrefix, 'w+') as w:
            w.write('\n'.join(scriptResult))
    else:
        with open('snpactf_result.tab', 'w+') as w:
            w.write('\n'.join(scriptResult))
